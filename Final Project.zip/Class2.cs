﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPFinalProject
{
    static class ConnectionClass
    {
        public static DataClasses1DataContext db = new DataClasses1DataContext();
    }
}
